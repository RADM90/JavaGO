
public class 빅데이터_200427_박제원_문항1 {

	public static void main(String[] args) {
		
		int pee = 50_000;
		
		
		int age = 22;
		
		if (age<5||age>65) {
			pee *= 0.5;
		} else if (age>=5&&age<=19) {
			pee *= 0.7;
		} else if (age>=1&&age<=100) {
			pee *= 1;
		} else {
			System.out.println("나이값 오류");
		}
		System.out.println("나이가 "+age+"세 이므로 입장료는 "+pee+"원 입니다.");
			
		
		//==========================================================================
		age = 70;
		pee = 50_000;
		
		if (age<5||age>65) {
			pee *= 0.5;
		} else if (age>=5&&age<=19) {
			pee *= 0.7;
		} else if (age>=1&&age<=100) {
			pee *= 1;
		} else {
			System.out.println("나이값 오류");
		}
		System.out.println("나이가 "+age+"세 이므로 입장료는 "+pee+"원 입니다.");

		
		//==========================================================================
		age = 14;
		pee = 50_000;
		
		if (age<5||age>65) {
			pee *= 0.5;
		} else if (age>=5&&age<=19) {
			pee *= 0.7;
		} else if (age>=1&&age<=100) {
			pee *= 1;
		} else {
			System.out.println("나이값 오류");
		}
		System.out.println("나이가 "+age+"세 이므로 입장료는 "+pee+"원 입니다.");
	}

}
