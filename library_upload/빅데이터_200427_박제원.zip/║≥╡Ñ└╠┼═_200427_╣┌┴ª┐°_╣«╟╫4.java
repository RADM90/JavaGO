import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;

public class 빅데이터_200427_박제원_문항4 {


	public static void main(String[] args) {
		new MemberJoinGUI();
	}
}


class MemberJoinGUI extends JFrame {
	JButton signInBtn, cancelBtn;
	JTextField nameField, idField;
	JPasswordField pwField;
	JLabel nameLabel, idLabel, pwLabel;
	public MemberJoinGUI() {
		showFrame();
	}
	
	
	public void showFrame() {
		setTitle("회원 정보 입력");
		setBounds(400, 400, 240, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel p = new JPanel();
		getContentPane().add(p);
		p.setLayout(null);
		
		idLabel = new JLabel("이름");
		idLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		idLabel.setBounds(12, 10, 66, 21);
		p.add(idLabel);
		idLabel = new JLabel("아이디");
		idLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		idLabel.setBounds(12, 40, 66, 21);
		p.add(idLabel);
		pwLabel = new JLabel("비밀번호");
		pwLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
		pwLabel.setBounds(12, 70, 83, 21);
		p.add(pwLabel);
		
		nameField = new JTextField();
		nameField.setBounds(91, 10, 124, 21);
		p.add(nameField);
		idField = new JTextField();
		idField.setBounds(91, 40, 124, 21);
		p.add(idField);
		pwField = new JPasswordField();
		pwField.setBounds(91, 70, 124, 21);
		p.add(pwField);
		
		signInBtn = new JButton("회원가입");
		signInBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!idCheck(idField.getText())) {
					signIn();
				} else {
					System.out.println("이미 존재하는 아이디");
				}
			}
		});
		signInBtn.setBounds(12, 110, 82, 21);
		p.add(signInBtn);
		
		cancelBtn = new JButton("취소");
		cancelBtn.setBounds(130, 110, 85, 21);
		p.add(cancelBtn);
		cancelBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				nameField.setText("");
				idField.setText("");
				pwField.setText("");
			}
		});
		setVisible(true);
	}
	
	public boolean idCheck(String id) {
		id = idField.getText();
		MemberDAO mdao= new MemberDAO();
		boolean checker = mdao.idCheck(id);
		return checker;
	}
	
	public void signIn() {
		String name = nameField.getText();
		String id = idField.getText();
		String password = new String(pwField.getPassword());
		if (name.equals("")) {
			JOptionPane.showMessageDialog(this, "이름 입력 필수");
			nameField.requestFocus();
			return;
		} else if (id.equals("")) {
			JOptionPane.showMessageDialog(this, "아이디 입력 필수");
			idField.requestFocus();
			return;
		} else if (password.length()==0) {
			JOptionPane.showMessageDialog(this, "비밀번호 입력 필수");
			pwField.requestFocus();
			return;
		} else {
			MemberDAO mdao = new MemberDAO();
			mdao.signIn(name, id, password);
		}
		
		
	}
}
